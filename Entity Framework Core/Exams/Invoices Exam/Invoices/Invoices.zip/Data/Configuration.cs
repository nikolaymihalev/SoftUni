﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
